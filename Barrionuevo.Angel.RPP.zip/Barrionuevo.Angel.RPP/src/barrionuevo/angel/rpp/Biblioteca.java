
package barrionuevo.angel.rpp;

import java.util.ArrayList;
import java.util.List;

public class Biblioteca 
{
    private List<Publicacion> publicaciones;
    private String nombre;

    public Biblioteca(String nombre)
    {
        this.publicaciones=new ArrayList<>();
        this.nombre=nombre;
    }
    
   public void agregarPublicacion(Publicacion publicacion)
    {
        if(publicacion==null)
        {
            throw new NullPointerException("Me pasaste un Null en lugar de una publicacion");
        }
        if(publicaciones.contains(publicacion))
        {
          throw new PublicacionRepetidaException();
        }

        this.publicaciones.add(publicacion);     
    }
    
    public void mostrarPublicaciones()
    {
        if(this.publicaciones.isEmpty())
        {
            System.out.println("No hay Publicaciones en la Lista");
        }
        else
        {
            for(Publicacion p : publicaciones)
            {
                System.out.println(p.mostrar());
            }
        }
    }
    public void leerPublicaciones()
    {
        for(Publicacion p : publicaciones)
        {
            if(p!=null && (p instanceof Leible l))
            {   
               l.leer();
            }
            if(p!=null && (p instanceof Ilustracion i))
            {  
               System.out.println("-----------");
               i.leer();
               System.out.println("-----------");
            }
        }
    }    
}
