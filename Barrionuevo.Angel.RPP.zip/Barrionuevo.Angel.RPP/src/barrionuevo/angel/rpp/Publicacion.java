
package barrionuevo.angel.rpp;

import java.util.Objects;

public abstract class Publicacion 
{
    private String titulo;
    private String anioPublicacion;

    public String getTitulo() {
        return titulo;
    }

    public String getAnioPublicacion() {
        return anioPublicacion;
    }

    public Publicacion(String titulo, String anioPublicacion) 
    {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if(this==o)
        {
            return true;
        }
        if((o==null)|| ((this.getClass())!= o.getClass()))
        {
            return false;
        }
        Publicacion compararConEstaPublicacion =(Publicacion)o;
        
        return (this.getTitulo().equals(compararConEstaPublicacion.getTitulo()) 
                    &&  this.getAnioPublicacion().equals(compararConEstaPublicacion.getAnioPublicacion()));
    }
    
     @Override
    public int hashCode()
    {
       return Objects.hash(titulo,anioPublicacion);    
    }
    
    public abstract String mostrar();
     
    @Override
    public String toString()
    {
        return "Titulo "+this.titulo+" Anio de Publicacion "+this.anioPublicacion;
    }
}
