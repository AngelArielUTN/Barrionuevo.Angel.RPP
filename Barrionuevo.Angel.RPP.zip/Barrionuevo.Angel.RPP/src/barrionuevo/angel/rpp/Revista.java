
package barrionuevo.angel.rpp;

public class Revista extends Publicacion implements Leible
{
   private String numeroDeEdicion;

    public Revista( String titulo, String numeroDeEdicion,String anioPublicacion) 
    {
        super(titulo, anioPublicacion);
        this.numeroDeEdicion = numeroDeEdicion;
    }
   
    @Override
    public void leer()
    {   
       System.out.println("Leyendo: "+this.mostrar());     
    }
    
    @Override
    public String mostrar()
    {
        return toString();
    }
    @Override
    public String toString()
    {
        return super.toString()+ " Revista [ numeroEdicion= "+this.numeroDeEdicion+"]";
    }
    
}
