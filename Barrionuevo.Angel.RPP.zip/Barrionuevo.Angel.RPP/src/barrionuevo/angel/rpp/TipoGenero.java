
package barrionuevo.angel.rpp;

public enum TipoGenero {
    FICCION(),
    NO_FICCION(),
    CIENCIA(),
    HISTORIA();
    private TipoGenero()
    {
        
    }
    
    @Override
    public String toString()
    {
        return super.toString().substring(0,1)+super.toString().substring(1).toLowerCase();
    }   
}
