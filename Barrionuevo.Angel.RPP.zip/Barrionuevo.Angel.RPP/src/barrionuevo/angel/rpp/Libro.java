
package barrionuevo.angel.rpp;

public class Libro extends Publicacion implements Leible
{
    private String autor;
    private TipoGenero genero;

    public Libro(String titulo, String anioPublicacion,String autor, TipoGenero genero ) 
    {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }
    
    @Override
    public void leer()
    {
       
       System.out.println("Leyendo: "+this.mostrar());   
      
    }
    @Override
    public String mostrar()
    {
        return toString();//"Libro ["+this.autor+","+this.genero+"]";
    }
    @Override
    public String toString()
    {
        return super.toString()+ " Libro ["+this.autor+","+this.genero+"]";
    }
}
