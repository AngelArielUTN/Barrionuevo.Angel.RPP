
package barrionuevo.angel.rpp;

public class BarrionuevoAngelRPP {

    public static void main(String[] args) 
    {
      Biblioteca biblioteca = new Biblioteca("Tecnologica");
      cargarBiblioteca(biblioteca);
      System.out.println("\n----------------------\n");
      System.out.println("MOSTRAR PUBLICACIONES");
      System.out.println("\n----------------------\n"); 
      
      biblioteca.mostrarPublicaciones();
      
      System.out.println("\n----------------------\n");
      System.out.println("LEER PUBLICACIONES");
      System.out.println("\n----------------------\n"); 
      
      biblioteca.leerPublicaciones();
      
    }
    public static void cargarBiblioteca(Biblioteca biblioteca )
    {
        try
      {
          biblioteca.agregarPublicacion(new Libro("Calculo Infinitesinal","1998","Leihthol",TipoGenero.CIENCIA));
          biblioteca.agregarPublicacion(new Libro("Algebra Lineal","2000","Blanco",TipoGenero.CIENCIA));
          biblioteca.agregarPublicacion(new Libro("Matematica Discreta","2001","Susana Granado Peralta",TipoGenero.CIENCIA));
          
          biblioteca.agregarPublicacion(new Revista("Argentina","2010","1ra"));
          biblioteca.agregarPublicacion(new Revista("Buenos Aires Turismo","2022","2da"));
          
          biblioteca.agregarPublicacion(new Ilustracion("Arte contemporaneo","2020","Hein",204,180));
          biblioteca.agregarPublicacion(new Ilustracion("Arte Visual","2021","Hein",320,190));
          biblioteca.agregarPublicacion(new Ilustracion("Arte Visual","2021","Hein",320,190));
      }
      catch(NullPointerException ex)
      {
          System.out.println(ex.getMessage());
      }
      catch(PublicacionRepetidaException ex)
      {
          System.out.println(ex.getMessage());
      }
      catch(Exception ex)
      {
          System.out.println(ex.getMessage());
      }
    }
}
