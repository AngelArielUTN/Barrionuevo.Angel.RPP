
package barrionuevo.angel.rpp;

public class Ilustracion extends Publicacion
{
    private String nombreDelIlustrador;
    private int ancho;
    private int alto;

    public Ilustracion(String titulo, String anioPublicacion ,String nombreDelIlustrador, int ancho, int alto) 
    {
        super(titulo, anioPublicacion);
        this.nombreDelIlustrador = nombreDelIlustrador;
        this.ancho = ancho;
        this.alto = alto;
    }
    
    public void leer()
    {  
       System.out.println("La Ilustracion "+super.toString()+" NO ES LEIBLE: ");    
    }
    
    @Override
    public String mostrar()
    {
        return toString();
    }
    @Override
    public String toString()
    {
        return super.toString()+ " Ilustracion[ ilustrador = "+this.nombreDelIlustrador+", ancho = "+this.ancho+" ,alto = "+this.alto+"]";
    }    
}
