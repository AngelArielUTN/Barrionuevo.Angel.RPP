
package barrionuevo.angel.rpp;

public class PublicacionRepetidaException extends RuntimeException {
 private static final String MENSAGE="No puede Agregar una publicacion que ya existe";
    
    public PublicacionRepetidaException()
    {
        super(MENSAGE);
    }     
}
