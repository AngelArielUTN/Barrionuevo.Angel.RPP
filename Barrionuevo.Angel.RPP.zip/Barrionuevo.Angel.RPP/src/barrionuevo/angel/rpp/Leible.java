
package barrionuevo.angel.rpp;

public interface Leible 
{
    public abstract void leer();
}
