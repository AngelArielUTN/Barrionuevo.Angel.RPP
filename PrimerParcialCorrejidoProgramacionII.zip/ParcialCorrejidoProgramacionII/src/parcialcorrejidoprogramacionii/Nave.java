package parcialcorrejidoprogramacionii;

import static java.lang.System.Logger.Level.values;
import java.util.Objects;

/*
/Nave/
--
-nombre:String
-capacidadDeTripulacion:int
-anioDeLanzamiento:int
--
+Nave(String nombre,int capacidadDeTripulacion, int anioDeLanzamiento)
/+iniciarExploracion():void/
*/
public abstract class Nave 
{
   private String nombre ;
   private int capacidadDeTripulacion;
   private int anioDeLanzamiento;

    public Nave(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento) {
        this.nombre = nombre;
        this.capacidadDeTripulacion = capacidadDeTripulacion;
        this.anioDeLanzamiento = anioDeLanzamiento;
    }
    public String getNombre()
    {
        return this.nombre;
    }
    public int getCapacidadDeTripulacion()
    {
        return this.capacidadDeTripulacion;
    }
    public int getAnioDeLanzamiento()
    {
        return this.anioDeLanzamiento;
    }
    
    public abstract void explorar();
    
    public void mostrar()
    {
        System.out.println(this.toString());
    }
    @Override
    public boolean equals(Object o)
    {
        if(this==o)
        {
            return true;
        }
        if((o==null)|| ((this.getClass())!= o.getClass()))
        {
            return false;
        }
        Nave compararConEstaNave =(Nave)o;
        
        return (this.getNombre().equals(compararConEstaNave.getNombre()) 
                    &&  this.getAnioDeLanzamiento()== (compararConEstaNave.getAnioDeLanzamiento()));  
    }
    
    @Override
    public int hashCode()
    {
       return Objects.hash(nombre,anioDeLanzamiento);    
    }
    
    @Override
    public String toString()
    {
        return  "Nombre: "+this.getNombre()+" Capacidad de Tripulacion: "+this.getCapacidadDeTripulacion() +"Anio de Lanzamiento: "+this.getAnioDeLanzamiento() ;//this.mostrar();
    }  
}
