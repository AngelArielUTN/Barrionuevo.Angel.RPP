package parcialcorrejidoprogramacionii;

import java.util.Objects;

/*
CruceroEstelar
--
-cantidadDePasajerosQuePuedeTransportar
--
+CruceroEstelar(String nombre,int capacidadDeTripulacion, int anioDeLanzamiento,int cantidadDePasajerosQuePuedeTransportar)
+explorar():void
*/
public class CruceroEstelar extends Nave
{
  private int cantidadDePasajerosQuePuedeTransportar;

    public CruceroEstelar(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento,int cantidadDePasajerosQuePuedeTransportar)
    {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.cantidadDePasajerosQuePuedeTransportar = cantidadDePasajerosQuePuedeTransportar;
    }
    @Override
    public void mostrar()
    {
        //this.mostrar();
        System.out.println(this.toString());
    }
    @Override
    public void explorar()
    {
        System.out.println("Nave Crucero Estelar NO PUEDE participar de esta  Mision ya que solo tyransportan pasajeros");
    }
    @Override
    public String toString()
    {
        return  super.toString()+ "Cantidad de Pasajeros que puede transportar: "+ this.cantidadDePasajerosQuePuedeTransportar;
    }  

     @Override
    public boolean equals(Object o)
    {

 
        return super.equals(o);
        
    }
    
    @Override
    public int hashCode()
    {
       return Objects.hash(this.getNombre(),this.getAnioDeLanzamiento());       
    }
}
