package parcialcorrejidoprogramacionii;
/*
NoPuedeAgregarUnaNaveExistenteException
--
__-MENSAGE:String="No puede Agregar la nave porque ya existe"__
+NoPuedeAgregarUnaNaveExistenteException(mensaje)
*/
public class NoPuedeAgregarUnaNaveExistenteException extends RuntimeException
{
  private static final String MENSAGE="No puede Agregar la nave porque ya existe";
    
    public NoPuedeAgregarUnaNaveExistenteException()
    {
        super(MENSAGE);
    }  
}
