package parcialcorrejidoprogramacionii;
/*
<<enum>>
--
TipoDeMision
--
+CARTOGRAFIA
+INVESTIGACION
+CONTACTO
*/
public enum TipoDeExploracion 
{
   CARTOGRAFIA(),
    INVESTIGACION(),
    CONTACTO();
    
    private TipoDeExploracion()
    {
        
    }
    
    @Override
    public String toString()
    {
        return super.toString().substring(0,1)+super.toString().substring(1).toLowerCase();
    } 
}
