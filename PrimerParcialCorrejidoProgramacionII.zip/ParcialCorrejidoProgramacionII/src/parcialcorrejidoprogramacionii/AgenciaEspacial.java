package parcialcorrejidoprogramacionii;

import java.util.ArrayList;
import java.util.List;

public class AgenciaEspacial 
{
    private ArrayList<Nave> naves;//= new ArrayList<Nave>();
    
    public AgenciaEspacial()
    {
       this.naves= new ArrayList<Nave>(); 
    }
    
    public void AgregarNave(Nave nave)
    {

  
        if(nave==null)
        {
            throw new NullPointerException("Me pasaste un Null en lugar de una nave");
        }
        if(naves.contains(nave))
        {
          throw new NoPuedeAgregarUnaNaveExistenteException();
        }

        this.naves.add(nave);     
    }
    
    public void mostrarNaves()
    {
        if(this.naves.isEmpty())
        {
            System.out.println("No hay Naves en la Lista");
        }
        else
        {
            for(Nave n : naves)
            {
                if(n!=null && (n instanceof NaveExploracion || n instanceof Carguero))
                {
                    n.mostrar();
                }      
            }
        }
    }
    public void iniciarExploracion()
    {
        for(Nave n : naves)
        {
            if(n!=null)
            {
                n.explorar();
            }      
        }
    }  
}
