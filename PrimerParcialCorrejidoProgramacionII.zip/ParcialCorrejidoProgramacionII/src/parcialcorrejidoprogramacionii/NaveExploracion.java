
package parcialcorrejidoprogramacionii;

import java.util.Objects;

/*
NaveExploracion
--
-tipoDeExploracion:TipoDeExploracion
--
+NaveExploracion(String nombre,int capacidadDeTripulacion, int anioDeLanzamiento,TipoDeExploracion tipoDeExploracion)

+explorar():void
*/
public class NaveExploracion extends Nave
{
  private TipoDeExploracion tipoDeExploracion;

    public NaveExploracion(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento,TipoDeExploracion tipoDeExploracion) 
    {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.tipoDeExploracion = tipoDeExploracion;
    }
    
    @Override
    public void explorar()
    {
        System.out.println("Nave de Exploracion iniciando Mision");
    }
    @Override
    public void mostrar()
    {
        //this.mostrar();
        System.out.println(this.toString());
    }
    @Override
    public String toString()
    {
        return  super.toString()+ "Tipo de Exploracion: "+ this.tipoDeExploracion.toString();
    } 

     @Override
    public boolean equals(Object o)
    {
        return super.equals(o);
    }
    
    @Override
    public int hashCode()
    {
       return Objects.hash(this.getNombre(),this.getAnioDeLanzamiento());    
    }
}
