
package parcialcorrejidoprogramacionii;

import java.util.Objects;

/*
Carguero
--
__-capacidadDeCargaMinimaToneladas :int =100__
__-capacidadDeCargaMaximaToneladas:int =500__
-carga:int
--
+Carguero(String nombre,int capacidadDeTripulacion, int anioDeLanzamiento,int carga)

+explorar():void
*/
public class Carguero extends Nave 
{
    private static final int capacidadDeCargaMinimaToneladas =100;
   private static final int capacidadDeCargaMaximaToneladas =500;
   private int carga;

    public Carguero(String nombre, int capacidadDeTripulacion, int anioDeLanzamiento,int carga ) 
    {
        super(nombre, capacidadDeTripulacion, anioDeLanzamiento);
        this.carga = this.validarCapacidadDeCarga(carga);
    }
    private int validarCapacidadDeCarga(int carga)
    {
        if(carga<Carguero.capacidadDeCargaMinimaToneladas || carga>Carguero.capacidadDeCargaMaximaToneladas)
        {
           throw new IllegalArgumentException();
        }
        return carga;
                
    }
     @Override
    public void mostrar()
    {
        System.out.println(this.toString());
    }
    
    @Override
    public void explorar()
    {
        System.out.println("Nave Carguero iniciando Mision");
    }
    @Override
    public String toString()
    {
        return  super.toString()+ "Carga: "+ this.carga;
    }

    
    @Override
    public boolean equals(Object o)
    {
        return super.equals(o);
    }
    
    @Override
    public int hashCode()
    {
       return Objects.hash(this.getNombre(),this.getAnioDeLanzamiento());       
    }
}
