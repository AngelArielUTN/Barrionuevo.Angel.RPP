package parcialcorrejidoprogramacionii;
/*
1. Agregar naves espaciales: o Se debe poder agregar un carguero llamado "Galáctica" 
con una capacidad de carga de 300 toneladas, 
y al intentar agregar otra nave con el mismo nombre y año de lanzamiento, se debe lanzar una excepción. 
2. Mostrar naves: o El sistema debe poder listar todas las naves, mostrando tanto los 
atributos comunes (nombre, capacidad de tripulación, año de lanzamiento)
como los específicos (tipo de misión, capacidad de carga o cantidad de pasajeros).
3. Iniciar exploración: o El sistema debe permitir que las naves de 
exploración y los cargueros inicien su misión, 
mientras que debe indicar que los cruceros estelares no pueden participar. 

NaveExploracion  (String nombre,int capacidadDeTripulacion, int anioDeLanzamiento,TipoDeExploracion tipoDeExploracion)
Carguero         (String nombre,int capacidadDeTripulacion, int anioDeLanzamiento,int carga)
CruceroEstelar   (String nombre,int capacidadDeTripulacion, int anioDeLanzamiento)
*/
public class ParcialCorrejidoProgramacionII 
{

    public static void main(String[] args)
    {
       AgenciaEspacial BrownieAstronomics = new AgenciaEspacial();
        
        NaveExploracion n1 = new NaveExploracion("Atom I",7,2001,TipoDeExploracion.INVESTIGACION);
        NaveExploracion n2 = new NaveExploracion("Atom II",14,2002,TipoDeExploracion.CARTOGRAFIA);
        
        Carguero n3 = new Carguero("Galactica",20,2003,300);
        Carguero n4 = new Carguero("Cobalente",20,2004,300);
        Carguero n5 = new Carguero("Ionica",24,2005,350);
        
        CruceroEstelar n6 = new CruceroEstelar("Diamante",20,2010,40);
        
        Carguero n7 = new Carguero("Galactica",20,2003,300);
       
        try
        {
            BrownieAstronomics.AgregarNave(n1);//(new NaveExploracion("Atom I",7,2001,TipoDeExploracion.INVESTIGACION));
            BrownieAstronomics.AgregarNave(n2);//(new NaveExploracion("Atom II",14,2002,TipoDeExploracion.CARTOGRAFIA));

            BrownieAstronomics.AgregarNave(n3);//(new Carguero("Galactica",20,2003,300));
            BrownieAstronomics.AgregarNave(n4);//(new Carguero("Cobalente",20,2004,300));
            BrownieAstronomics.AgregarNave(n5);//(new Carguero("Ionica",24,2005,350));

            BrownieAstronomics.AgregarNave(n6);//(new CruceroEstelar("Diamante",20,2010,40));

            BrownieAstronomics.AgregarNave(n7);//(new Carguero("Galactica",20,2003,300));
        }
        catch(NullPointerException ex)
        {
            System.out.println(ex.getMessage());
        }
        catch(NoPuedeAgregarUnaNaveExistenteException ex)
        {
            System.out.println(ex.getMessage());
        }

        System.out.println("\n-------------------------\n");
        System.out.println(" Lista de NAVES: \n");
        System.out.println("\n-------------------------\n");
        BrownieAstronomics.mostrarNaves();
        
        System.out.println("-------------------------");
        System.out.println("Iniciando EXPLORACION: \n");
        System.out.println("\n-------------------------\n");
        BrownieAstronomics.iniciarExploracion(); 
    }
    
}
